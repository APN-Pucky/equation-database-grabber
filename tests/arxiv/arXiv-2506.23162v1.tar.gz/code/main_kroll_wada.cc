// main_kroll_wada.cc

//#define LHE 1
//#define HEPMC 1
#define RIVET 1

//#define SIMPLE  // simple 
//#define VINCIA // VINCIA
//#define DIRE // DIRE

//#define SINGLE // veto everything but first emission
#define ENHANCE // use a2ll to enhance photon -> ee splitting
//#define FULL

//#define PHENIX200
#define ALICE7000
//#define ALICE5020

// Prohibit more than one of the above
#if defined(PHENIX200) + defined(ALICE7000) + defined(ALICE5020) != 1
#error "Exactly one of PHENIX200, ALICE7000, ALICE5020 must be defined"
#endif

#include "Pythia8/Pythia.h"

#ifdef RIVET
#include "Pythia8Plugins/Pythia8Rivet.h"
#include "Rivet/AnalysisHandler.hh"
#endif

#ifdef HEPMC
#include "Pythia8Plugins/HepMC3.h"
#endif

#include <iostream>
#include <chrono>  // For timing

using namespace Pythia8;

class MyUserHooks : public UserHooks {
  // Allow a veto after (by default) first step.
  bool canVetoFSREmission() {
    //exit(-1);
	  return true;
  }
  // Access the event in the interleaved evolution after first step.
  bool  doVetoFSREmission( int sizeOld, const Event& event, int iSys, bool inResonance = false)   {
    if (sizeOld > 7) {
      return true;
    }
    return false;
  }
};

int main(int argc, char* argv[]) {
  int totalIterations = 10000;
  std::string filename = "event";

  if (argc > 1){
	filename = argv[1]; 
  }
  if (argc > 2){
	totalIterations = atoi(argv[2]);
  }

  // Generator.
  Pythia pythia;

  // Set up to do a user veto and send it in.
#ifdef SINGLE
  auto myUserHooks = make_shared<MyUserHooks>();
  pythia.setUserHooksPtr( myUserHooks );
#endif

  //pythia.readString("PDF:pSet = LHAPDF6:NNPDF40_nlo_as_01180/0");
  pythia.readString("Check:event = off");

  // On shell prompt photon
  //pythia.readString("PromptPhoton:all = on");
  // we do not want boxes:
  pythia.readString("PromptPhoton:qg2qgamma = on");
  pythia.readString("PromptPhoton:qqbar2ggamma = on");

  // Kroll-Wada
#ifdef ENHANCE
  pythia.readString("Enhancements:doEnhance = on");
  pythia.readString("EnhancedSplittings:List = { isr:A2AQ=1.,isr:Q2QA=1.,fsr:Q2QA=1.,fsr:A2LL=200.0 }");
#endif
  // disable other lepton sources
  pythia.readString("HadronLevel:all = off");
  pythia.readString("HadronLevel:Decay = off");
  pythia.readString("PartonLevel:MPI = off");
#ifndef FULL
  pythia.readString("PartonLevel:ISR = off");
#endif
  pythia.readString("PartonLevel:FSR = on");
  pythia.readString("PartonLevel:Remnants = off");


#ifdef SIMPLE
  pythia.readString("PartonShowers:model  = 1");
  pythia.readString("SpaceShower:QEDshowerByQ=off");
  pythia.readString("TimeShower:QEDshowerByQ=off");
  // disable QCD shower (=> more QED shower?)
#ifndef FULL
  pythia.readString("TimeShower:QCDshower=off");
  pythia.readString("SpaceShower:QCDshower=off");

  // only photon -> e
  pythia.readString("TimeShower:nGammaToLepton = 1"); 
  pythia.readString("TimeShower:nGammaToQuark = 0");
#endif
#endif
#ifdef DIRE
  pythia.readString("PartonShowers:model=3");
  //pythia.readString("DireSpace:nFinalMax = 0");
  //pythia.readString("DireTimes:nFinalMax = 8");

#ifndef FULL
  pythia.readString("TimeShower:QEDshowerByL=on");
  pythia.readString("TimeShower:QEDshowerByGamma=on");

  pythia.readString("TimeShower:QCDshower=off");
  pythia.readString("SpaceShower:QCDshower=off");
  //pythia.readString("Enhance:Dire_fsr_qed_22->11&11a = 1000");
  //pythia.readString("Enhance:Dire_fsr_qed_22->11&11b = 1000");
#endif
#endif
#ifdef VINCIA
  pythia.readString("PartonShowers:model  = 2");
  pythia.readString("Vincia:mMaxGamma = 10.0"); //1.0 (10.0 default)
  //disable QCD
  pythia.readString("Vincia:QminChgQ = 2.0");
  //pythia.readString("Vincia:convertQuarkToGamma = off");
#ifndef FULL
  pythia.readString("Vincia:nGammaToLepton = 1");
  pythia.readString("Vincia:nGammaToQuark = 0");
  pythia.readString("Vincia:nGluonToQuark = 0");
  pythia.readString("Vincia:convertGluonToQuark = off");
  pythia.readString("Vincia:convertQuarkToGluon = off");
#endif
#endif

  // Use time based seed
  pythia.readString("Random:setSeed = on");
  pythia.readString("Random:seed = 0");

  pythia.readString("PhaseSpace:pTHatMin = 0"); 
  pythia.readString("PhaseSpace:pTHatMax = 10"); 

#ifdef PHENIX200
  pythia.readString("Beams:eCM = 200."); 
#endif
#ifdef ALICE5020
  pythia.readString("Beams:eCM = 5020.");
#endif
#ifdef ALICE7000
  pythia.readString("Beams:eCM = 7000."); 
#endif

#ifdef LHE
  // Create an LHAup object that can access relevant information in pythia.
  LHAupFromPYTHIA8 myLHA(&pythia.process, &pythia.info);

  // Open a file on which LHEF events should be stored, and write header.
  myLHA.openLHEF(filename + ".lhe");

  // Store initialization info in the LHAup object.
  myLHA.setInit();

  // Write out this initialization info on the file.
  myLHA.initLHEF();
#endif

#ifdef RIVET
  //*
  Pythia8Rivet rivet(pythia, filename + ".yoda");
  rivet.ignoreBeams(true);
  rivet.addAnalysis("ALICE_2020_I1797621");
  rivet.addAnalysis("MC_KROLL_WADA");
  rivet.addAnalysis("MC_FSPARTICLES");
  rivet.addAnalysis("MC_DILEPTON");
  rivet.addAnalysis("PHENIX_2019_I1672015");
  rivet.addAnalysis("ATLAS_2014_I1288706");
  rivet.addAnalysis("PHENIX_2009_I838580");
  //*/
#endif


#ifdef HEPMC
  ///*
  // Interface for conversion from Pythia8::Event to HepMC event.
  Pythia8ToHepMC toHepMC(filename + ".hepmc");
  //*/
#endif

   // Extract settings to be used in the main program.
  int    nEvent    = pythia.mode("Main:numberOfEvents");
  int    nAbort    = pythia.mode("Main:timesAllowErrors");

  // Initialization.
  pythia.init();

  // Begin event loop.
  int iAbort = 0;

  // Loop over events.
  for (int i = 0; i < totalIterations; ++i) {

    // Generate event.
    if (!pythia.next()) {

      // If failure because reached end of file then exit event loop.
      if (pythia.info.atEndOfFile()) {
        cout << " Aborted since reached end of Les Houches Event File\n";
        break;
      }

      // First few failures write off as "acceptable" errors, then quit.
      if (++iAbort < nAbort) continue;
      cout << " Event generation aborted prematurely, owing to error!\n";
      break;
    }
#ifdef RIVET
    rivet();
#endif

#ifdef LHE
    // Store event info in the LHAup object.
    myLHA.setEvent();

    // Write out this event info on the file.
    // With optional argument (verbose =) false the file is smaller.
    myLHA.eventLHEF();
#endif
    
#ifdef HEPMC
    toHepMC.writeNextEvent( pythia );
    // */
#endif
  }
#ifdef RIVET
  rivet.done();
#endif

  // Statistics: full printout.
  pythia.stat();

#ifdef LHE
  // Update the cross section info based on Monte Carlo integration during run.
  myLHA.updateSigma();

  // Write endtag. Overwrite initialization info with new cross sections.
  myLHA.closeLHEF(true);
#endif

  // Done.
  return 0;
}


