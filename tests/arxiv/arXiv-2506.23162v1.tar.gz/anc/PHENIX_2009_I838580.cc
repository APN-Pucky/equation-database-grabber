// -*- C++ -*-
#include "Rivet/Analysis.hh"
#include "Rivet/Projections/FinalState.hh"
#include "Rivet/Projections/PromptFinalState.hh"
#include "Rivet/Projections/FastJets.hh"
#include "Rivet/Projections/ZFinder.hh"

namespace Rivet
{

	/// @brief Add a short analysis description here
	class PHENIX_2009_I838580: public Analysis
	{
		public:

			const double JET_R = 0.5;


			const int npdgid = 999;
			int _photon = 0;
			int _bottom = 0;
			int _charm = 0;
			int _open = 0;
			int _apid = 0;
			int _qq = 0;
			int _qg = 0;
			int _gg = 0;

			/// Constructor
			RIVET_DEFAULT_ANALYSIS_CTOR(PHENIX_2009_I838580);

            			/// @name Analysis methods
			//@{

			/// Book histograms and initialise projections before the run
			void init()
			{
				// FinalState fs;
				//Cut cuts = (Cuts::pT > 0.2 * GeV) && (Cuts::pT < 10 * GeV) && (Cuts::abseta < 0.8);
				Cut nocuts = (Cuts::pT > 0*GeV);
				 Cut cuts =  (Cuts::pT > 0.2*GeV);

				FinalState fs1 = FinalState(Cuts::pid == PID::ELECTRON && cuts);
				//PromptFinalState pfs1 = PromptFinalState(Cuts::pid == PID::ELECTRON && nocuts);
				declare(fs1, "Elecs");
				FinalState fs2 = FinalState(Cuts::pid == -PID::ELECTRON && cuts);
				//PromptFinalState pfs2 = PromptFinalState(Cuts::pid == -PID::ELECTRON && nocuts);
				declare(fs2, "Posis");
				FinalState afs = FinalState(nocuts);
				declare(afs, "All");

                book(_h1["m_ee"], 39,1,1);
            }

            void analyze(const Event& event) {
                Particles elecs, posis;
				elecs = apply<ParticleFinder>(event, "Elecs").particlesByPt();
				posis = apply<ParticleFinder>(event, "Posis").particlesByPt();

                if (elecs.size() != 1 || posis.size() != 1) {
                    vetoEvent;
                }

                FourMomentum p_ee = elecs[0].momentum() + posis[0].momentum();

				Particles all = apply<ParticleFinder>(event, "All").particlesByPt();

				auto mee = p_ee.mass();
				if (1.0 < p_ee.pT()  && p_ee.pT() < 1.5 && p_ee.abseta() < 0.35)
                	_h1["m_ee"]->fill(mee);
            }


            			/// Normalise histograms etc., after the run
			void finalize()
			{
				normalize(_h1);
				scale(_h1,3.900000e-02*5.000000e-03/ _h1["m_ee"]->binAt(5.000000e-03/2).sumW() );




				// scale(_h,crossSection());
				// const double sf = crossSection() / sumOfWeights();
				// scale(_h["mll"], sf);
			}

			//@}

			/// @name Histograms
			//@{
			map<string, Histo1DPtr> _h1;
			map<string, Histo2DPtr> _h2;
			// map<string, Scatter2DPtr> _s;
			//@}
	};

	// The hook for the plugin system
	RIVET_DECLARE_PLUGIN(PHENIX_2009_I838580);
}
