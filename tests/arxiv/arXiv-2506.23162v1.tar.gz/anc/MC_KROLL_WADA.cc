// -*- C++ -*-
#include "Rivet/Analysis.hh"
#include "Rivet/Projections/FinalState.hh"
#include "Rivet/Projections/PromptFinalState.hh"
#include "Rivet/Projections/FastJets.hh"
#include "Rivet/Projections/ZFinder.hh"

namespace Rivet
{

	/// @brief Add a short analysis description here
	class MC_KROLL_WADA : public Analysis
	{
		public:

			const double JET_R = 0.5;


			const int npdgid = 999;
			int _photon = 0;
			int _bottom = 0;
			int _charm = 0;
			int _open = 0;
			int _apid = 0;
			int _qq = 0;
			int _qg = 0;
			int _gg = 0;

			/// Constructor
			RIVET_DEFAULT_ANALYSIS_CTOR(MC_KROLL_WADA);

            			/// @name Analysis methods
			//@{

			/// Book histograms and initialise projections before the run
			void init()
			{
				// FinalState fs;
				//Cut cuts = (Cuts::pT > 0.2 * GeV) && (Cuts::pT < 10 * GeV) && (Cuts::abseta < 0.8);
				Cut nocuts = (Cuts::pT > 0*GeV);
				// Cut cuts =  (Cuts::pT > 10.*GeV)    && (Cuts::abseta < 2.5);

				FinalState fs1 = FinalState(Cuts::pid == PID::ELECTRON && nocuts);
				//PromptFinalState pfs1 = PromptFinalState(Cuts::pid == PID::ELECTRON && nocuts);
				declare(fs1, "Elecs");
				FinalState fs2 = FinalState(Cuts::pid == -PID::ELECTRON && nocuts);
				//PromptFinalState pfs2 = PromptFinalState(Cuts::pid == -PID::ELECTRON && nocuts);
				declare(fs2, "Posis");
				FinalState afs = FinalState(nocuts);
				declare(afs, "All");

                book(_h1["m_ee"], "m_ee", 100, 0, 10);
                book(_h1["p_ee"], "p_ee", 100, 0, 10);
                book(_h1["p_e"], "p_e", 100, 0, 10);
                book(_h2["mp_ee"], "mp_ee", 100, 0, 10, 100, 0, 10);
				book(_h1["s"], "s", 100,0,100);
				book(_h1["kw"], "kw", 100,0,10);

                book(_h1["ALICE_m_ee"], "ALICE_m_ee", {0,0.04,0.09, 0.14,0.19,0.24, 0.29,0.34,0.39,0.44,0.5,0.6,0.7});
            }

            void analyze(const Event& event) {
                Particles elecs, posis;
				elecs = apply<ParticleFinder>(event, "Elecs").particlesByPt();
				posis = apply<ParticleFinder>(event, "Posis").particlesByPt();

                if (elecs.size() == 0 || posis.size() == 0) {
                    vetoEvent;
                }

                FourMomentum p_ee = elecs[0].momentum() + posis[0].momentum();

				Particles all = apply<ParticleFinder>(event, "All").particlesByPt();

				auto mee = p_ee.mass();
				auto mee2 = mee*mee;
					//std::cout << "mee " <<  mee << std::endl;
                _h1["m_ee"]->fill(mee);
                _h1["p_ee"]->fill(p_ee.pT());
                _h1["p_e"]->fill(elecs[0].momentum().pT());
                _h1["p_e"]->fill(posis[0].momentum().pT());
                _h2["mp_ee"]->fill(p_ee.mass(), p_ee.pT());

				auto tot = all[0].momentum()- all[0].momentum();
				for ( auto p : all){
					tot += p.momentum();
				}
				auto s = tot.mass();
				_h1["s"]->fill(s);
				_h1["kw"]->fill(1/mee2 * ( 1-  mee2/s)* ( 1- mee2/s)* ( 1-  mee2/s));

				if(3 < p_ee.pt() &&  p_ee.pt() < 4 && elecs[0].momentum().abseta() < 0.8 && posis[0].momentum().abseta() < 0.8&& elecs[0].momentum().pT() > 0.2 && posis[0].momentum().pT() > 0.2) {
                _h1["ALICE_m_ee"]->fill(mee);

				}
            }


            			/// Normalise histograms etc., after the run
			void finalize()
			{
				// normalize(_h);
				scale(_h1, crossSectionPerEvent() / (millibarn));
				scale(_h2, crossSectionPerEvent() / (millibarn));




				// scale(_h,crossSection());
				// const double sf = crossSection() / sumOfWeights();
				// scale(_h["mll"], sf);
			}

			//@}

			/// @name Histograms
			//@{
			map<string, Histo1DPtr> _h1;
			map<string, Histo2DPtr> _h2;
			// map<string, Scatter2DPtr> _s;
			//@}
	};

	// The hook for the plugin system
	RIVET_DECLARE_PLUGIN(MC_KROLL_WADA);
}
